from pygame.math import Vector2 as vec


# Postavke zaslona
WIDTH, HEIGHT = 908, 644
FPS = 60
BUFFER = 50
MAZE_WIDTH, MAZE_HEIGHT = WIDTH - BUFFER, HEIGHT - BUFFER
LOGO_WIDTH, LOGO_HEIGHT = WIDTH//2, HEIGHT//2

ROWS = 27
COLS = 39

# Postavke boje
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (208, 22, 22)
BLUE = (63, 72, 204)
YELLOW = (239, 230, 0)
GREY = (107, 107, 107)
PINK = (255, 105, 180)
PLAYER_COLOUR = (190, 194, 15)

# Postavke teksta
START_TEXT_SIZE = 16
START_FONT = 'arial black'




