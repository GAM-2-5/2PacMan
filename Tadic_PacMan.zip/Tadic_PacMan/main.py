from app_class import * #Unosi sve funkcije app_class.py datoteke

if __name__ == '__main__':  #Pokrece igricu
    app = App()
    app.run()
